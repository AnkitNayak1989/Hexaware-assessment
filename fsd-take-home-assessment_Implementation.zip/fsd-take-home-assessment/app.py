from __future__ import annotations

from flask import Flask, jsonify, render_template, request

from reconcile import build_meetings, load_events

app = Flask(__name__)


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/api/health")
def health():
    try:
        crm, calendar = load_events()
        return jsonify(
            {
                "status": "ok",
                "sources": {"crm": len(crm), "calendar": len(calendar)},
            }
        )
    except (OSError, ValueError) as exc:
        return jsonify({"status": "error", "detail": str(exc)}), 503


@app.get("/api/meetings")
def meetings():
    try:
        result = build_meetings()
    except (OSError, ValueError) as exc:
        return jsonify({"error": str(exc)}), 503

    items = result["meetings"]
    query = request.args.get("q", "").strip().casefold()
    source = request.args.get("source", "").strip().casefold()
    conflict_filter = request.args.get("conflicts", "").strip().casefold()
    status = request.args.get("status", "").strip().casefold()
    date_from = request.args.get("from", "").strip()
    date_to = request.args.get("to", "").strip()

    if query:
        items = [
            item
            for item in items
            if query
            in " ".join(
                [
                    str(item.get(field) or "")
                    for field in (
                        "title",
                        "client",
                        "company",
                        "owner",
                        "location",
                        "date",
                        "status",
                    )
                ]
            ).casefold()
        ]
    if source in {"crm", "calendar"}:
        items = [item for item in items if item["sources"].get(source)]
    if conflict_filter in {"true", "1", "yes"}:
        items = [item for item in items if item["conflicts"]]
    if status:
        items = [item for item in items if (item.get("status") or "").casefold() == status]
    if date_from:
        items = [item for item in items if item.get("date") and item["date"] >= date_from]
    if date_to:
        items = [item for item in items if item.get("date") and item["date"] <= date_to]

    return jsonify(
        {
            "meetings": items,
            "total": len(items),
            "summary": result["summary"],
            "data_quality": result["data_quality"],
        }
    )


@app.get("/api/meetings/<meeting_id>")
def meeting_detail(meeting_id: str):
    result = build_meetings()
    for item in result["meetings"]:
        if item["id"] == meeting_id:
            return jsonify(item)
    return jsonify({"error": "Meeting not found."}), 404


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)

import unittest
from pathlib import Path

from app import app
from reconcile import build_meetings

ROOT = Path(__file__).resolve().parents[1]


class ReconciliationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.result = build_meetings(ROOT / "data")
        cls.by_crm = {}
        for meeting in cls.result["meetings"]:
            crm_source = meeting["sources"]["crm"]
            if crm_source:
                cls.by_crm[crm_source["id"]] = meeting

    def test_known_cross_source_pairs(self):
        expected = {
            "CRM-1001": "CAL-A1",
            "CRM-1004": "CAL-A4",
            "CRM-1009": "CAL-A10",
            "CRM-1017": "CAL-A20",
            "CRM-1019": "CAL-A22",
        }
        for crm_id, calendar_id in expected.items():
            with self.subTest(crm_id=crm_id):
                meeting = self.by_crm[crm_id]
                self.assertEqual(meeting["sources"]["calendar"]["id"], calendar_id)
                self.assertTrue(meeting["match"]["matched"])

    def test_duplicate_calendar_record_is_preserved_and_flagged(self):
        meeting = self.by_crm["CRM-1005"]
        source = meeting["sources"]["calendar"]
        duplicate_ids = {record["id"] for record in source["duplicate_records"]}
        self.assertEqual(source["id"], "CAL-A5")
        self.assertEqual(duplicate_ids, {"CAL-A6"})
        self.assertEqual(self.result["summary"]["same_source_duplicates"], 1)

    def test_conflicts_are_visible_with_source_values(self):
        location_conflict = self.by_crm["CRM-1002"]["conflicts"]
        self.assertIn("location", {item["field"] for item in location_conflict})
        status_conflict = self.by_crm["CRM-1009"]["conflicts"]
        self.assertIn("status", {item["field"] for item in status_conflict})

    def test_malformed_data_is_retained_and_reported(self):
        malformed_date = self.by_crm["CRM-1008"]
        self.assertEqual(malformed_date["date"], "2025-03-15")
        warning_messages = [
            item["message"] for item in self.result["data_quality"]["warnings"]
        ]
        self.assertTrue(any("Malformed attendee address" in message for message in warning_messages))

    def test_rest_api_lists_meetings_and_supports_conflict_filter(self):
        client = app.test_client()
        response = client.get("/api/meetings")
        self.assertEqual(response.status_code, 200)
        self.assertGreater(response.json["total"], 0)
        self.assertIn("summary", response.json)

        conflict_response = client.get("/api/meetings?conflicts=true")
        self.assertEqual(conflict_response.status_code, 200)
        self.assertTrue(all(item["conflicts"] for item in conflict_response.json["meetings"]))

    def test_health_and_single_meeting_endpoint(self):
        client = app.test_client()
        health = client.get("/api/health")
        self.assertEqual(health.json["status"], "ok")

        meeting_id = self.result["meetings"][0]["id"]
        detail = client.get(f"/api/meetings/{meeting_id}")
        self.assertEqual(detail.status_code, 200)
        self.assertEqual(detail.json["id"], meeting_id)


if __name__ == "__main__":
    unittest.main()

# AI collaboration notes

AI assistance was used to inspect the assessment and provided JSON feeds, propose a transparent reconciliation approach, implement the Flask API and browser UI, and create focused tests and setup documentation.

## Decisions made with AI assistance

- Preserve malformed or incomplete source records and attach data-quality warnings instead of silently dropping them.
- Interpret the sample CRM value `03-15/2025` as month-day-year and keep its original form in source provenance.
- Require same-day evidence and meaningful identity/title support for cross-source matches; keep candidate matching one-to-one.
- Treat close, same-date calendar entries with overlapping attendees and shared title terms as possible same-source duplicates, but retain the duplicate's original data for review.
- Flag differences in locations, statuses, times, and apparent virtual/in-person mode. Do not convert timezones when the CRM timezone is absent.
- Keep matching confidence/reasons and all original source fields visible so users can audit heuristic decisions.

These are explicit working choices for the supplied sample dataset, not guaranteed universal rules for arbitrary CRM/calendar feeds. The service has tests for the important sample cases and the thresholds can be adapted when domain-specific matching requirements are known.

# Event Sync Service

A small Flask service that ingests CRM and calendar JSON feeds, reconciles likely duplicate meetings, exposes the unified results through a REST API, and provides a browser interface for exploring source data, conflicts, and data-quality warnings.

## Run it

Requires Python 3.9+ and Flask.

```bash
cd fsd-take-home-assessment
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

Open <http://127.0.0.1:5000/>. The application reads `data/crm_events.json` and `data/calendar_events.json` on each API request, so source file changes are visible after refreshing.

## API

### `GET /api/health`

Reports service health and the number of loaded rows from each source.

### `GET /api/meetings`

Returns a JSON object with `meetings`, `total`, source reconciliation `summary`, and `data_quality` warnings/duplicate decisions.

Supported query parameters:

| Parameter | Example | Behavior |
| --- | --- | --- |
| `q` | `?q=Meridian` | Case-insensitive search over title, client, company, owner, location, date, and status |
| `source` | `?source=crm` | Restrict to meetings that have a CRM record (`calendar` is also supported) |
| `status` | `?status=Confirmed` | Case-insensitive exact status filter |
| `conflicts` | `?conflicts=true` | Return only meetings with conflicting source values |
| `from`, `to` | `?from=2025-03-10&to=2025-03-20` | Inclusive date bounds in `YYYY-MM-DD` format |

Example:

```bash
curl 'http://127.0.0.1:5000/api/meetings?conflicts=true'
```

### `GET /api/meetings/<meeting_id>`

Returns a single reconciled meeting, including the original source records and the reasons for any match. URL-encode `+` in a combined meeting ID when constructing a path manually.

### Browser UI

The home page presents searchable/filterable meetings, summary counts, detected conflicts, data-quality warnings, and expandable CRM/calendar source fields. Source IDs and the values behind conflicts are kept visible for auditability.

## Reconciliation approach

1. **Ingest:** Load both JSON arrays, retain original records, and normalize usable dates/times. The known CRM date `03-15/2025` is interpreted as month-day-year. Unparseable values remain in the source record and are reported as data-quality warnings rather than causing the record to disappear.
2. **Deduplicate within calendar:** Group records only when they share a date, start within 45 minutes, have overlapping attendees, and share title terms. The chosen original and duplicate record are both retained in the API response. Distinct recurring meeting instances on different dates are not collapsed.
3. **Match CRM to calendar:** Candidate pairs must have the same normalized date. A weighted score considers client/company names in calendar text and attendees, shared identifying title terms, start-time proximity, and location. A match also needs strong client/company evidence or a close title and time combination. Candidate pairs are processed from highest score down and each source record is used at most once.
4. **Merge conservatively:** CRM supplies the preferred display title, date, and status when present; the calendar supplies attendees, recurrence, and a fallback location/status. Raw source records remain present, and each selected field lists its source.
5. **Report conflicts:** Different non-empty locations and statuses are shown as conflicts. A meeting-type/location-mode disagreement is also flagged. Different start times are reported without guessing timezone conversion: the CRM feed has no timezone field, while calendar values may contain `Z`. Matching date/time parsing never modifies the preserved source value.
6. **Surface quality issues:** Missing/invalid dates, invalid times, missing titles, and malformed attendee addresses are warnings attached to the meeting and summarized by the API.

The matching score is a pragmatic heuristic, not a claim of certainty. The API returns the score, confidence indicator, and matching reasons so a user can review decisions. Records without a sufficiently supported match remain source-only meetings. The data set is small, so reconciliation runs in memory from the source files for each request.

## Decisions and limitations

- No third-party matching or database package is required; Flask is the only runtime dependency.
- Timezone conversion is intentionally avoided. The CRM feed has only a wall-clock time; the calendar feed can include an explicit `Z`. Conflicts show the original timestamps where the values differ.
- A record with a bad date is preserved in the output but cannot be cross-matched or placed in date filters.
- Calendar title and CRM subject are independently named fields, so differing labels alone are not marked a conflict when the evidence supports that they are the same meeting.
- Source JSON is treated as trusted local input. This is a demo and does not include authentication, persistent storage, or upstream API polling.

## Tests

```bash
python -m unittest discover -s tests -v
```

Tests cover the identified cross-source matches, the within-calendar duplicate, conflict visibility, malformed data, API filtering, health, and meeting detail retrieval.

## AI collaboration note

See [AI_NOTES.md](AI_NOTES.md) for a concise record of AI assistance, assumptions, and implementation decisions, included to make collaboration transparent.

## Time spent

Elapsed implementation time was not tracked, so no numeric estimate is claimed. This solution was produced with AI assistance; please add your own hands-on time estimate before submitting the assessment.

from __future__ import annotations

import json
import re
import unicodedata
from datetime import date, datetime
from pathlib import Path
from typing import Any

DATA_DIR = Path(__file__).resolve().parent / "data"
STOP_WORDS = {
    "a",
    "an",
    "and",
    "at",
    "call",
    "discussion",
    "for",
    "in",
    "meeting",
    "of",
    "on",
    "q1",
    "q2",
    "the",
    "to",
    "with",
}
ALIASES = {
    "lpac": ("lp", "advisory", "committee"),
    "qbr": ("quarterly", "business", "review"),
}


def load_events(data_dir: Path = DATA_DIR) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Load and minimally validate the two source feeds."""
    feeds = []
    for filename in ("crm_events.json", "calendar_events.json"):
        path = data_dir / filename
        try:
            content = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ValueError(f"Could not read {filename}: {exc}") from exc
        if not isinstance(content, list):
            raise ValueError(f"{filename} must contain a JSON array.")
        feeds.append([row for row in content if isinstance(row, dict)])
    return feeds[0], feeds[1]


def normalize(value: Any) -> str:
    text = unicodedata.normalize("NFKD", str(value or "")).casefold()
    text = "".join(char for char in text if not unicodedata.combining(char))
    return " ".join(re.findall(r"[a-z0-9]+", text))


def tokens(value: Any) -> set[str]:
    result: set[str] = set()
    for token in normalize(value).split():
        result.update(ALIASES.get(token, (token,)))
    return result - STOP_WORDS


def parse_date(value: Any) -> date | None:
    if not isinstance(value, str):
        return None
    text = value.strip()
    try:
        return datetime.fromisoformat(text.replace("Z", "+00:00")).date()
    except ValueError:
        pass
    for pattern in ("%m-%d/%Y", "%m/%d/%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(text, pattern).date()
        except ValueError:
            continue
    return None


def parse_calendar_start(value: Any) -> tuple[date | None, str | None]:
    if not isinstance(value, str):
        return None, None
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None, None
    # Preserve the upstream wall-clock value: the feed does not identify a
    # timezone for CRM times, so converting one source to another is unsafe.
    return parsed.date(), value.strip()[11:]


def parse_minutes(value: Any) -> int | None:
    if not isinstance(value, str):
        return None
    try:
        parsed = datetime.fromisoformat(
            f"2000-01-01T{value.strip().replace('Z', '+00:00')}"
        )
    except ValueError:
        try:
            parsed = datetime.strptime(value.strip(), "%I:%M %p")
        except ValueError:
            return None
    return parsed.hour * 60 + parsed.minute


def prepare(source: str, row: dict[str, Any], index: int) -> dict[str, Any]:
    warnings: list[str] = []
    if source == "crm":
        record_id = str(row.get("crm_id") or f"CRM-row-{index + 1}")
        raw_date = row.get("meeting_date")
        event_date = parse_date(raw_date)
        raw_time = row.get("meeting_time")
        title = row.get("subject")
        client = row.get("client_name")
        company = row.get("client_company")
        location = row.get("location")
        time_value = raw_time
        if raw_date and not event_date:
            warnings.append(f"Unrecognized CRM meeting_date: {raw_date!r}.")
    else:
        record_id = str(row.get("event_id") or f"CAL-row-{index + 1}")
        raw_date = row.get("start_time")
        event_date, calendar_time = parse_calendar_start(raw_date)
        raw_time = calendar_time
        title = row.get("title")
        client = None
        company = None
        location = row.get("location")
        time_value = raw_time
        if raw_date and not event_date:
            warnings.append(f"Unrecognized calendar start_time: {raw_date!r}.")
        attendees = row.get("attendees")
        if attendees is not None and not isinstance(attendees, list):
            warnings.append("Calendar attendees must be an array.")
        elif isinstance(attendees, list):
            for attendee in attendees:
                if isinstance(attendee, str) and "@" not in attendee:
                    warnings.append(f"Malformed attendee address: {attendee!r}.")

    if not title:
        warnings.append("Meeting title is missing.")
    if not event_date:
        warnings.append("Meeting date is missing or invalid.")
    normalized_date = event_date.isoformat() if event_date else None
    time_minutes = parse_minutes(time_value)
    if time_value and time_minutes is None:
        warnings.append(f"Unrecognized meeting time: {time_value!r}.")
    return {
        "source": source,
        "id": record_id,
        "raw": row,
        "date": normalized_date,
        "raw_date": raw_date,
        "time": time_value,
        "minutes": time_minutes,
        "title": str(title).strip() if title else None,
        "client": str(client).strip() if client else None,
        "company": str(company).strip() if company else None,
        "location": str(location).strip() if location else None,
        "warnings": warnings,
    }


def title_similarity(left: dict[str, Any], right: dict[str, Any]) -> float:
    a = tokens(left.get("title"))
    b = tokens(right.get("title"))
    if not a or not b:
        return 0.0
    return len(a & b) / min(len(a), len(b))


def same_place(left: Any, right: Any) -> bool:
    a = normalize(left)
    b = normalize(right)
    return bool(a and b and (a == b or a in b or b in a))


def identity_match(crm: dict[str, Any], calendar: dict[str, Any]) -> tuple[int, bool]:
    row = calendar["raw"]
    attendees = row.get("attendees")
    attendees = attendees if isinstance(attendees, list) else []
    searchable = " ".join(
        [
            str(row.get("title") or ""),
            str(row.get("description") or ""),
            " ".join(str(item) for item in attendees if isinstance(item, str)),
        ]
    )
    search_tokens = tokens(searchable)
    score = 0
    strong = False

    for value, weight in ((crm.get("client"), 6), (crm.get("company"), 5)):
        entity_tokens = tokens(value)
        if not entity_tokens:
            continue
        overlap = len(entity_tokens & search_tokens)
        ratio = overlap / len(entity_tokens)
        if ratio >= 0.8:
            score += weight
            strong = True
        elif ratio >= 0.5:
            score += 2

    # Compare full attendee email names as names, including malformed but
    # recognizable addresses such as "raj.patel[at]atlasvc.com".
    email_names = []
    for address in attendees:
        if not isinstance(address, str):
            continue
        local = address.split("@", 1)[0].replace("[at]", ".")
        email_names.append(tokens(local.replace(".", " ")))
    if crm.get("client"):
        person_tokens = tokens(crm["client"])
        if person_tokens and any(
            len(person_tokens & name_tokens) / len(person_tokens) >= 0.8
            for name_tokens in email_names
        ):
            score += 6
            strong = True
    return score, strong


def candidate_score(crm: dict[str, Any], calendar: dict[str, Any]) -> dict[str, Any] | None:
    if not crm.get("date") or crm["date"] != calendar.get("date"):
        return None

    score = 4
    why = ["same calendar date"]
    identity_points, strong_identity = identity_match(crm, calendar)
    score += identity_points
    if identity_points:
        why.append("client or company appears in calendar details")

    similarity = title_similarity(crm, calendar)
    if similarity >= 0.5:
        score += 3
        why.append("titles share identifying terms")

    delta = None
    if crm.get("minutes") is not None and calendar.get("minutes") is not None:
        delta = abs(crm["minutes"] - calendar["minutes"])
        if delta <= 45:
            score += 2
            why.append("start times are within 45 minutes")
        elif delta <= 90:
            score += 1
            why.append("start times are within 90 minutes")

    if same_place(crm.get("location"), calendar.get("location")):
        score += 1
        why.append("locations agree")

    supported = strong_identity or (similarity >= 0.5 and delta is not None and delta <= 90)
    if score < 7 or not supported:
        return None
    return {
        "score": score,
        "title_similarity": similarity,
        "time_delta_minutes": delta,
        "why": why,
    }


def record_completeness(event: dict[str, Any]) -> int:
    return sum(
        bool(event["raw"].get(key))
        for key in (
            "subject",
            "title",
            "client_name",
            "client_company",
            "relationship_owner",
            "meeting_time",
            "start_time",
            "location",
            "notes",
            "description",
        )
    )


def deduplicate_calendar(
    events: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    groups: list[dict[str, Any]] = []
    duplicate_links: list[dict[str, Any]] = []
    for event in events:
        duplicate_group = None
        for group in groups:
            representative = group["records"][0]
            if not event.get("date") or event["date"] != representative.get("date"):
                continue
            left_time = event.get("minutes")
            right_time = representative.get("minutes")
            if left_time is None or right_time is None or abs(left_time - right_time) > 45:
                continue
            attendees_a = {
                normalize(address)
                for address in (event["raw"].get("attendees") or [])
                if isinstance(address, str)
            }
            attendees_b = {
                normalize(address)
                for address in (representative["raw"].get("attendees") or [])
                if isinstance(address, str)
            }
            union = attendees_a | attendees_b
            participant_overlap = len(attendees_a & attendees_b) / len(union) if union else 0
            similarity = title_similarity(event, representative)
            matching_company = bool(
                tokens(event["raw"].get("title")) & tokens(representative["raw"].get("title"))
            )
            if participant_overlap >= 0.5 and (similarity >= 0.25 or matching_company):
                duplicate_group = group
                break

        if duplicate_group is None:
            groups.append({"records": [event]})
        else:
            duplicate_group["records"].append(event)
            duplicate_links.append(
                {
                    "kept": duplicate_group["records"][0]["id"],
                    "duplicate": event["id"],
                    "reason": "Same date, overlapping attendees, similar event title, and starts within 45 minutes.",
                }
            )
    return groups, duplicate_links


def choose_pair_record(
    crm: dict[str, Any], calendar_group: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any]]:
    scored = [
        (candidate_score(crm, record), record)
        for record in calendar_group["records"]
    ]
    score, chosen = max(scored, key=lambda item: item[0]["score"] if item[0] else -1)
    assert score is not None
    return chosen, score


def value_entries(
    crm: dict[str, Any] | None,
    calendar: dict[str, Any] | None,
    field: str,
) -> list[dict[str, Any]]:
    entries = []
    if crm:
        if field == "title":
            value = crm["raw"].get("subject")
        elif field == "date":
            value = crm["raw"].get("meeting_date")
        elif field == "time":
            value = crm["raw"].get("meeting_time")
        elif field == "location":
            value = crm["raw"].get("location")
        elif field == "status":
            value = crm["raw"].get("status")
        elif field == "meeting_type":
            value = crm["raw"].get("meeting_type")
        else:
            value = None
        if value not in (None, ""):
            entries.append({"source": "crm", "record_id": crm["id"], "value": value})

    if calendar:
        raw = calendar["raw"]
        if field == "title":
            value = raw.get("title")
        elif field == "date":
            value = raw.get("start_time")
        elif field == "time":
            value = raw.get("start_time")
        elif field == "location":
            value = raw.get("location")
        elif field == "status":
            value = raw.get("status")
        elif field == "meeting_type":
            location = normalize(raw.get("location"))
            value = "Virtual" if any(word in location for word in ("zoom", "virtual", "teams")) else None
        else:
            value = None
        if value not in (None, ""):
            entries.append({"source": "calendar", "record_id": calendar["id"], "value": value})
    return entries


def mode_from_value(value: Any) -> str | None:
    normalized = normalize(value)
    if not normalized:
        return None
    if any(word in normalized.split() for word in ("zoom", "virtual", "teams", "online")):
        return "virtual"
    if normalized in {"in person", "inperson"} or "in person" in normalized:
        return "in-person"
    if "office" in normalized or "room" in normalized or "conference" in normalized:
        return "in-person"
    return None


def make_conflicts(crm: dict[str, Any] | None, calendar: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not crm or not calendar:
        return []
    conflicts: list[dict[str, Any]] = []
    for field in ("location", "status"):
        entries = value_entries(crm, calendar, field)
        if len(entries) != 2:
            continue
        left, right = entries[0]["value"], entries[1]["value"]
        if field == "location":
            equal = same_place(left, right) or (
                mode_from_value(left) is not None
                and mode_from_value(left) == mode_from_value(right)
            )
        else:
            equal = normalize(left) == normalize(right)
        if not equal:
            conflicts.append(
                {"field": field, "values": entries, "message": "Sources report different values."}
            )

    crm_time = parse_minutes(crm["raw"].get("meeting_time"))
    calendar_time = calendar.get("minutes")
    if crm_time is not None and calendar_time is not None and crm_time != calendar_time:
        conflicts.append(
            {
                "field": "time",
                "values": value_entries(crm, calendar, "time"),
                "message": (
                    "Start times differ. The CRM timezone is not provided, so the service "
                    "does not assume the timestamps can be converted."
                ),
            }
        )

    crm_date = crm.get("date")
    calendar_date = calendar.get("date")
    if crm_date and calendar_date and crm_date != calendar_date:
        conflicts.append(
            {
                "field": "date",
                "values": value_entries(crm, calendar, "date"),
                "message": "Sources report different dates.",
            }
        )

    crm_mode = mode_from_value(crm["raw"].get("meeting_type"))
    calendar_mode = mode_from_value(calendar["raw"].get("location"))
    if crm_mode and calendar_mode and crm_mode != calendar_mode:
        conflicts.append(
            {
                "field": "meeting_type",
                "values": value_entries(crm, calendar, "meeting_type"),
                "message": "CRM meeting type conflicts with the calendar location's apparent mode.",
            }
        )
    return conflicts


def build_meeting(
    crm: dict[str, Any] | None,
    calendar: dict[str, Any] | None,
    calendar_duplicates: list[dict[str, Any]],
    match: dict[str, Any] | None,
) -> dict[str, Any]:
    crm_raw = crm["raw"] if crm else {}
    calendar_raw = calendar["raw"] if calendar else {}
    primary_id = crm["id"] if crm else calendar["id"]
    source_ids = [source["id"] for source in (crm, calendar) if source]
    duplicate_ids = [record["id"] for record in calendar_duplicates]
    meeting_id = "+".join(source_ids + duplicate_ids)

    date_value = (crm or calendar or {}).get("date")
    raw_time = crm_raw.get("meeting_time") if crm else calendar.get("time") if calendar else None
    title = (crm_raw.get("subject") if crm else None) or (
        calendar_raw.get("title") if calendar else None
    ) or "Untitled meeting"
    client = crm_raw.get("client_name") if crm else None
    company = crm_raw.get("client_company") if crm else None
    attendees = calendar_raw.get("attendees") if calendar else None
    raw_calendar_time = calendar_raw.get("start_time") if calendar else None

    field_sources = {
        "title": value_entries(crm, calendar, "title"),
        "date": value_entries(crm, calendar, "date"),
        "time": value_entries(crm, calendar, "time"),
        "location": value_entries(crm, calendar, "location"),
        "status": value_entries(crm, calendar, "status"),
    }

    warnings = []
    if crm:
        warnings.extend({"source": "crm", "record_id": crm["id"], "message": item} for item in crm["warnings"])
    if calendar:
        warnings.extend(
            {"source": "calendar", "record_id": calendar["id"], "message": item}
            for item in calendar["warnings"]
        )
    for duplicate in calendar_duplicates:
        warnings.extend(
            {"source": "calendar", "record_id": duplicate["id"], "message": item}
            for item in duplicate["warnings"]
        )

    sources = {
        "crm": {"id": crm["id"], "fields": crm_raw} if crm else None,
        "calendar": {
            "id": calendar["id"],
            "fields": calendar_raw,
            "duplicate_records": [
                {"id": record["id"], "fields": record["raw"]}
                for record in calendar_duplicates
            ],
        }
        if calendar
        else None,
    }
    conflicts = make_conflicts(crm, calendar)
    return {
        "id": meeting_id,
        "title": title,
        "date": date_value,
        "time": raw_time,
        "calendar_time": raw_calendar_time,
        "client": client,
        "company": company,
        "owner": crm_raw.get("relationship_owner") if crm else None,
        "attendees": attendees if isinstance(attendees, list) else [],
        "location": (crm_raw.get("location") if crm else None)
        or (calendar_raw.get("location") if calendar else None),
        "meeting_type": crm_raw.get("meeting_type") if crm else None,
        "status": (crm_raw.get("status") if crm else None)
        or (calendar_raw.get("status") if calendar else None),
        "is_recurring": calendar_raw.get("is_recurring") if calendar else None,
        "sources": sources,
        "field_sources": field_sources,
        "conflicts": conflicts,
        "data_quality": warnings,
        "match": {
            "matched": bool(crm and calendar),
            "confidence": round(min(match["score"] / 16, 1), 2) if match else None,
            "score": match["score"] if match else None,
            "reason": match["why"] if match else [],
        },
    }


def build_meetings(data_dir: Path = DATA_DIR) -> dict[str, Any]:
    crm_rows, calendar_rows = load_events(data_dir)
    crm_events = [prepare("crm", row, index) for index, row in enumerate(crm_rows)]
    calendar_events = [
        prepare("calendar", row, index) for index, row in enumerate(calendar_rows)
    ]

    calendar_groups, duplicate_links = deduplicate_calendar(calendar_events)
    pair_candidates = []
    for crm_index, crm in enumerate(crm_events):
        for group_index, group in enumerate(calendar_groups):
            for calendar in group["records"]:
                score = candidate_score(crm, calendar)
                if score:
                    pair_candidates.append(
                        (score["score"], crm_index, group_index, calendar["id"], score)
                    )
    pair_candidates.sort(key=lambda item: (-item[0], item[1], item[2], item[3]))

    matched_crm: set[int] = set()
    matched_calendar_groups: set[int] = set()
    pair_by_crm: dict[int, tuple[int, dict[str, Any], dict[str, Any]]] = {}
    for _, crm_index, group_index, _calendar_id, score in pair_candidates:
        if crm_index in matched_crm or group_index in matched_calendar_groups:
            continue
        chosen_calendar, chosen_score = choose_pair_record(
            crm_events[crm_index], calendar_groups[group_index]
        )
        matched_crm.add(crm_index)
        matched_calendar_groups.add(group_index)
        pair_by_crm[crm_index] = (group_index, chosen_calendar, chosen_score)

    duplicate_ids_by_kept: dict[str, list[str]] = {}
    for link in duplicate_links:
        duplicate_ids_by_kept.setdefault(link["kept"], []).append(link["duplicate"])

    meetings = []
    for crm_index, crm in enumerate(crm_events):
        if crm_index in pair_by_crm:
            group_index, chosen_calendar, score = pair_by_crm[crm_index]
            group = calendar_groups[group_index]
            duplicate_records = [
                record
                for record in group["records"]
                if record["id"] != chosen_calendar["id"]
            ]
            meetings.append(build_meeting(crm, chosen_calendar, duplicate_records, score))
        else:
            meetings.append(build_meeting(crm, None, [], None))

    for group_index, group in enumerate(calendar_groups):
        if group_index in matched_calendar_groups:
            continue
        primary = max(group["records"], key=record_completeness)
        duplicates = [record for record in group["records"] if record["id"] != primary["id"]]
        meetings.append(build_meeting(None, primary, duplicates, None))

    meetings.sort(key=lambda item: (item.get("date") or "9999-99-99", parse_minutes(item.get("time")) or 0, item["id"]))
    crm_matched = sum(bool(item["sources"]["crm"] and item["sources"]["calendar"]) for item in meetings)
    crm_only = sum(bool(item["sources"]["crm"] and not item["sources"]["calendar"]) for item in meetings)
    calendar_only = sum(bool(item["sources"]["calendar"] and not item["sources"]["crm"]) for item in meetings)
    return {
        "meetings": meetings,
        "summary": {
            "crm_records": len(crm_events),
            "calendar_records": len(calendar_events),
            "cross_source_matches": crm_matched,
            "crm_only": crm_only,
            "calendar_only": calendar_only,
            "same_source_duplicates": len(duplicate_links),
            "conflicted_meetings": sum(bool(item["conflicts"]) for item in meetings),
        },
        "data_quality": {
            "warnings": [
                warning for item in meetings for warning in item["data_quality"]
            ],
            "duplicates": duplicate_links,
        },
    }

const list = document.querySelector("#meeting-list");
const search = document.querySelector("#search");
const sourceFilter = document.querySelector("#source-filter");
const statusFilter = document.querySelector("#status-filter");
const conflictsOnly = document.querySelector("#conflicts-only");
const errorBanner = document.querySelector("#error");
const emptyState = document.querySelector("#empty-state");

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined && text !== null) node.textContent = String(text);
  return node;
}

function value(value, fallback = "Not provided") {
  return value === null || value === undefined || value === "" ? fallback : value;
}

function appendFact(parent, label, text) {
  const wrapper = element("div");
  wrapper.append(element("span", "fact-label", label), element("span", "fact-value", value(text)));
  parent.append(wrapper);
}

function sourcePanel(label, source) {
  const panel = element("section", "source-panel");
  panel.append(element("h3", "", label));
  if (!source) {
    panel.append(element("p", "card-subtitle", "No record from this source."));
    return panel;
  }
  const fields = source.fields || {};
  const entries = Object.entries(fields).filter(([, fieldValue]) =>
    fieldValue !== null && fieldValue !== "" && !(Array.isArray(fieldValue) && !fieldValue.length)
  );
  const dl = element("dl");
  for (const [key, fieldValue] of entries) {
    const display = Array.isArray(fieldValue) ? fieldValue.join(", ") : fieldValue;
    dl.append(element("dt", "", key.replaceAll("_", " ")), element("dd", "", display));
  }
  panel.append(dl);

  for (const duplicate of source.duplicate_records || []) {
    panel.append(element("h3", "", `Duplicate source record · ${duplicate.id}`));
    const duplicateList = element("dl");
    for (const [key, fieldValue] of Object.entries(duplicate.fields || {})) {
      if (fieldValue === null || fieldValue === "") continue;
      duplicateList.append(
        element("dt", "", key.replaceAll("_", " ")),
        element("dd", "", Array.isArray(fieldValue) ? fieldValue.join(", ") : fieldValue),
      );
    }
    panel.append(duplicateList);
  }
  return panel;
}

function renderMeeting(meeting) {
  const card = element("article", "meeting-card");
  const head = element("div", "card-head");
  const heading = element("div");
  heading.append(element("h3", "card-title", meeting.title));
  const secondary = [meeting.client, meeting.company].filter(Boolean).join(" · ");
  heading.append(element("p", "card-subtitle", secondary || meeting.owner || "No client details in CRM"));
  const pills = element("div", "pills");
  if (meeting.sources.crm) pills.append(element("span", "pill crm", `CRM · ${meeting.sources.crm.id}`));
  if (meeting.sources.calendar) pills.append(element("span", "pill calendar", `Calendar · ${meeting.sources.calendar.id}`));
  if (meeting.sources.calendar?.duplicate_records?.length) {
    pills.append(element("span", "pill warning", `${meeting.sources.calendar.duplicate_records.length} duplicate`));
  }
  if (meeting.conflicts.length) pills.append(element("span", "pill conflict", `${meeting.conflicts.length} conflict${meeting.conflicts.length === 1 ? "" : "s"}`));
  head.append(heading, pills);
  card.append(head);

  const facts = element("div", "card-facts");
  appendFact(facts, "Date", meeting.date);
  appendFact(facts, "Start time", meeting.time);
  appendFact(facts, "Location", meeting.location);
  appendFact(facts, "Status", meeting.status);
  card.append(facts);

  if (meeting.conflicts.length) {
    const conflictList = element("div", "conflict-list");
    for (const conflict of meeting.conflicts) {
      const item = element("div", "conflict-item");
      item.append(element("strong", "", `${conflict.field} conflict: `));
      item.append(document.createTextNode(`${conflict.message} `));
      for (const sourceValue of conflict.values) {
        const span = element("span", "conflict-value", `${sourceValue.source}: ${sourceValue.value}`);
        item.append(span, document.createTextNode(" "));
      }
      conflictList.append(item);
    }
    card.append(conflictList);
  }

  const details = element("details", "source-detail");
  details.append(element("summary", "", "Inspect source fields and provenance"));
  const detailGrid = element("div", "detail-grid");
  detailGrid.append(
    sourcePanel("CRM source", meeting.sources.crm),
    sourcePanel("Calendar source", meeting.sources.calendar),
  );
  details.append(detailGrid);

  if (meeting.match.matched) {
    details.append(
      element(
        "p",
        "match-note",
        `Reconciliation confidence ${Math.round(meeting.match.confidence * 100)}% · ${meeting.match.reason.join("; ")}.`,
      ),
    );
  }
  if (meeting.data_quality.length) {
    const warnings = element("ul", "warning-list");
    for (const warning of meeting.data_quality) {
      warnings.append(
        element("li", "", `${warning.source} ${warning.record_id}: ${warning.message}`),
      );
    }
    details.append(warnings);
  }
  card.append(details);
  return card;
}

function buildUrl() {
  const params = new URLSearchParams();
  if (search.value.trim()) params.set("q", search.value.trim());
  if (sourceFilter.value) params.set("source", sourceFilter.value);
  if (statusFilter.value) params.set("status", statusFilter.value);
  if (conflictsOnly.checked) params.set("conflicts", "true");
  const query = params.toString();
  return query ? `/api/meetings?${query}` : "/api/meetings";
}

async function loadMeetings() {
  errorBanner.hidden = true;
  try {
    const response = await fetch(buildUrl(), { headers: { Accept: "application/json" } });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || `Request failed (${response.status}).`);

    document.querySelector("#metric-total").textContent = payload.summary.crm_records + payload.summary.calendar_records - payload.summary.cross_source_matches - payload.summary.same_source_duplicates;
    document.querySelector("#metric-matched").textContent = payload.summary.cross_source_matches;
    document.querySelector("#metric-conflicts").textContent = payload.summary.conflicted_meetings;
    document.querySelector("#metric-warnings").textContent = payload.data_quality.warnings.length;
    document.querySelector("#result-count").textContent = `${payload.total} shown`;
    list.replaceChildren(...payload.meetings.map(renderMeeting));
    emptyState.hidden = payload.meetings.length > 0;
  } catch (error) {
    errorBanner.textContent = `Could not load meetings: ${error.message}`;
    errorBanner.hidden = false;
    list.replaceChildren();
  }
}

let searchTimer;
search.addEventListener("input", () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(loadMeetings, 180);
});
sourceFilter.addEventListener("change", loadMeetings);
statusFilter.addEventListener("change", loadMeetings);
conflictsOnly.addEventListener("change", loadMeetings);
document.querySelector("#refresh-button").addEventListener("click", loadMeetings);

loadMeetings();
